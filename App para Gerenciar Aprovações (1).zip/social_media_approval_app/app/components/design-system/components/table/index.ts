
export { LiquidTable, liquidTableVariants } from './liquid-table'
export type { LiquidTableProps, Column } from './liquid-table'
