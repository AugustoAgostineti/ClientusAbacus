
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

const supabaseUrl = 'https://ztauiusnkquhifyzkjxh.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp0YXVpdXNua3F1aGlmeXpranhoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MzcyMTQ0NSwiZXhwIjoyMDY5Mjk3NDQ1fQ.4p5T6EhwQx2t0QDLD3S4ZU9TGNSMW7BFPkHmjA6q8dc';

async function executeSchema() {
  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    console.log('🚀 Iniciando execução do schema no Supabase...');
    
    // Ler o arquivo SQL
    const sqlPath = path.join(__dirname, 'supabase-schema.sql');
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');
    
    // Executar SQL usando RPC (se disponível) ou queries individuais
    console.log('📄 Arquivo SQL carregado. Executando...');
    
    const { data, error } = await supabase.rpc('exec_sql', { 
      sql: sqlContent 
    });
    
    if (error) {
      console.error('❌ Erro ao executar SQL via RPC:', error);
      
      // Tentativa alternativa: executar comandos individuais
      console.log('🔄 Tentando abordagem alternativa...');
      
      // Dividir o SQL em comandos individuais
      const commands = sqlContent
        .split(';')
        .map(cmd => cmd.trim())
        .filter(cmd => cmd.length > 0 && !cmd.startsWith('--'));
      
      console.log(`📝 Encontrados ${commands.length} comandos SQL`);
      
      for (let i = 0; i < commands.length; i++) {
        const command = commands[i];
        if (command.trim()) {
          console.log(`⚡ Executando comando ${i + 1}/${commands.length}...`);
          
          const { error: cmdError } = await supabase.rpc('exec_sql', { 
            sql: command + ';' 
          });
          
          if (cmdError) {
            console.error(`❌ Erro no comando ${i + 1}:`, cmdError);
            break;
          }
        }
      }
    } else {
      console.log('✅ Schema executado com sucesso!', data);
    }
    
    // Verificar se as tabelas foram criadas
    console.log('🔍 Verificando tabelas criadas...');
    
    const { data: tables, error: tablesError } = await supabase
      .from('information_schema.tables')
      .select('table_name')
      .eq('table_schema', 'public');
    
    if (tablesError) {
      console.error('❌ Erro ao verificar tabelas:', tablesError);
    } else {
      console.log('📋 Tabelas criadas:');
      tables?.forEach(table => console.log(`  - ${table.table_name}`));
    }
    
  } catch (err) {
    console.error('💥 Erro geral:', err);
  }
}

executeSchema();
