
-- ========================================
-- SUPABASE SCHEMA PARA SISTEMA DE APROVAÇÃO DE CONTEÚDO
-- ========================================

-- Limpar schema existente
DROP TABLE IF EXISTS public.notifications CASCADE;
DROP TABLE IF EXISTS public.content_history CASCADE;
DROP TABLE IF EXISTS public.comments CASCADE;
DROP TABLE IF EXISTS public.approvals CASCADE;
DROP TABLE IF EXISTS public.documents CASCADE;
DROP TABLE IF EXISTS public.contents CASCADE;
DROP TABLE IF EXISTS public.sessions CASCADE;
DROP TABLE IF EXISTS public.accounts CASCADE;
DROP TABLE IF EXISTS public.verification_tokens CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;

-- Limpar types existentes
DROP TYPE IF EXISTS public."ContentStatus" CASCADE;
DROP TYPE IF EXISTS public."ContentType" CASCADE;
DROP TYPE IF EXISTS public."NotificationType" CASCADE;
DROP TYPE IF EXISTS public."Platform" CASCADE;
DROP TYPE IF EXISTS public."UserRole" CASCADE;

-- ========================================
-- CRIAR ENUM TYPES
-- ========================================

CREATE TYPE public."ContentStatus" AS ENUM (
    'DRAFT',
    'PENDING_APPROVAL',
    'APPROVED',
    'REVISION_REQUESTED',
    'REJECTED',
    'PUBLISHED'
);

CREATE TYPE public."ContentType" AS ENUM (
    'IMAGE',
    'CAROUSEL',
    'VIDEO',
    'STORY'
);

CREATE TYPE public."NotificationType" AS ENUM (
    'CONTENT_CREATED',
    'APPROVAL_REQUESTED',
    'CONTENT_APPROVED',
    'REVISION_REQUESTED',
    'CONTENT_REJECTED',
    'CONTENT_PUBLISHED'
);

CREATE TYPE public."Platform" AS ENUM (
    'INSTAGRAM',
    'FACEBOOK',
    'TIKTOK',
    'YOUTUBE'
);

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN_AGENCY',
    'EMPLOYEE_AGENCY',
    'CLIENT'
);

-- ========================================
-- CRIAR TABELAS
-- ========================================

-- Tabela Users (base para tudo)
CREATE TABLE public.users (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT UNIQUE,
    "emailVerified" TIMESTAMPTZ,
    image TEXT,
    password TEXT,
    role public."UserRole" NOT NULL DEFAULT 'CLIENT',
    "companyName" TEXT,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "agencyManagerId" TEXT REFERENCES public.users(id)
);

-- Tabelas NextAuth
CREATE TABLE public.accounts (
    id TEXT PRIMARY KEY,
    "userId" TEXT NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    provider TEXT NOT NULL,
    "providerAccountId" TEXT NOT NULL,
    refresh_token TEXT,
    access_token TEXT,
    expires_at INTEGER,
    token_type TEXT,
    scope TEXT,
    id_token TEXT,
    session_state TEXT,
    UNIQUE(provider, "providerAccountId")
);

CREATE TABLE public.sessions (
    id TEXT PRIMARY KEY,
    "sessionToken" TEXT UNIQUE NOT NULL,
    "userId" TEXT NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    expires TIMESTAMPTZ NOT NULL
);

CREATE TABLE public.verification_tokens (
    identifier TEXT NOT NULL,
    token TEXT UNIQUE NOT NULL,
    expires TIMESTAMPTZ NOT NULL,
    UNIQUE(identifier, token)
);

-- Tabela Contents
CREATE TABLE public.contents (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    caption TEXT,
    "contentType" public."ContentType" NOT NULL,
    platforms public."Platform"[] NOT NULL DEFAULT '{}',
    "mediaUrls" TEXT[] NOT NULL DEFAULT '{}',
    "thumbnailUrl" TEXT,
    status public."ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "scheduledDate" TIMESTAMPTZ,
    "publishedAt" TIMESTAMPTZ,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "creatorId" TEXT NOT NULL REFERENCES public.users(id),
    "assigneeId" TEXT REFERENCES public.users(id)
);

-- Tabela Approvals
CREATE TABLE public.approvals (
    id TEXT PRIMARY KEY,
    approved BOOLEAN,
    feedback TEXT,
    "approvedAt" TIMESTAMPTZ,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "contentId" TEXT NOT NULL REFERENCES public.contents(id) ON DELETE CASCADE,
    "approverId" TEXT NOT NULL REFERENCES public.users(id)
);

-- Tabela Comments
CREATE TABLE public.comments (
    id TEXT PRIMARY KEY,
    message TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "contentId" TEXT NOT NULL REFERENCES public.contents(id) ON DELETE CASCADE,
    "authorId" TEXT NOT NULL REFERENCES public.users(id)
);

-- Tabela Content History
CREATE TABLE public.content_history (
    id TEXT PRIMARY KEY,
    "contentId" TEXT NOT NULL REFERENCES public.contents(id) ON DELETE CASCADE,
    version INTEGER NOT NULL DEFAULT 1,
    "changeReason" TEXT,
    "changedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "previousData" JSONB NOT NULL,
    "newData" JSONB NOT NULL,
    "changedFields" TEXT[] NOT NULL DEFAULT '{}',
    "changedById" TEXT NOT NULL REFERENCES public.users(id)
);

-- Tabela Documents
CREATE TABLE public.documents (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "fileSize" INTEGER,
    "mimeType" TEXT,
    description TEXT,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "uploaderId" TEXT NOT NULL REFERENCES public.users(id)
);

-- Tabela Notifications
CREATE TABLE public.notifications (
    id TEXT PRIMARY KEY,
    type public."NotificationType" NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    read BOOLEAN NOT NULL DEFAULT FALSE,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "recipientId" TEXT NOT NULL REFERENCES public.users(id),
    "senderId" TEXT REFERENCES public.users(id),
    "contentId" TEXT REFERENCES public.contents(id)
);

-- ========================================
-- CRIAR ÍNDICES PARA PERFORMANCE
-- ========================================

CREATE INDEX idx_users_email ON public.users(email);
CREATE INDEX idx_users_role ON public.users(role);
CREATE INDEX idx_accounts_user_id ON public.accounts("userId");
CREATE INDEX idx_sessions_user_id ON public.sessions("userId");
CREATE INDEX idx_sessions_token ON public.sessions("sessionToken");
CREATE INDEX idx_contents_creator_id ON public.contents("creatorId");
CREATE INDEX idx_contents_assignee_id ON public.contents("assigneeId");
CREATE INDEX idx_contents_status ON public.contents(status);
CREATE INDEX idx_contents_created_at ON public.contents("createdAt");
CREATE INDEX idx_approvals_content_id ON public.approvals("contentId");
CREATE INDEX idx_approvals_approver_id ON public.approvals("approverId");
CREATE INDEX idx_comments_content_id ON public.comments("contentId");
CREATE INDEX idx_comments_author_id ON public.comments("authorId");
CREATE INDEX idx_notifications_recipient_id ON public.notifications("recipientId");
CREATE INDEX idx_notifications_read ON public.notifications(read);
CREATE INDEX idx_notifications_created_at ON public.notifications("createdAt");

-- ========================================
-- CONFIGURAR ROW LEVEL SECURITY (RLS)
-- ========================================

-- Habilitar RLS nas tabelas principais
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Políticas básicas (podem ser ajustadas conforme necessidade)
-- Política para Users: usuários podem ver e editar seus próprios dados
CREATE POLICY "Users can view own data" ON public.users
    FOR SELECT USING (auth.uid()::text = id);

CREATE POLICY "Users can update own data" ON public.users
    FOR UPDATE USING (auth.uid()::text = id);

-- Política para Contents: criadores podem ver/editar seus conteúdos
CREATE POLICY "Users can view own contents" ON public.contents
    FOR SELECT USING (
        auth.uid()::text = "creatorId" OR 
        auth.uid()::text = "assigneeId"
    );

CREATE POLICY "Users can create contents" ON public.contents
    FOR INSERT WITH CHECK (auth.uid()::text = "creatorId");

CREATE POLICY "Users can update own contents" ON public.contents
    FOR UPDATE USING (auth.uid()::text = "creatorId");

-- ========================================
-- FUNÇÃO AUXILIAR PARA ATUALIZAR updated_at
-- ========================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW."updatedAt" = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para atualizar automaticamente o campo updatedAt
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_contents_updated_at BEFORE UPDATE ON public.contents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_approvals_updated_at BEFORE UPDATE ON public.approvals
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_comments_updated_at BEFORE UPDATE ON public.comments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON public.documents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ========================================
-- COMENTÁRIOS DE DOCUMENTAÇÃO
-- ========================================

COMMENT ON TABLE public.users IS 'Tabela de usuários do sistema (agências e clientes)';
COMMENT ON TABLE public.contents IS 'Tabela principal de conteúdos para aprovação';
COMMENT ON TABLE public.approvals IS 'Tabela de aprovações de conteúdo';
COMMENT ON TABLE public.comments IS 'Tabela de comentários em conteúdos';
COMMENT ON TABLE public.content_history IS 'Histórico de alterações em conteúdos';
COMMENT ON TABLE public.documents IS 'Tabela de documentos/arquivos';
COMMENT ON TABLE public.notifications IS 'Tabela de notificações do sistema';

-- ========================================
-- FINALIZAÇÃO
-- ========================================

-- Verificar se todas as tabelas foram criadas
SELECT 
    schemaname,
    tablename,
    tableowner
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY tablename;
