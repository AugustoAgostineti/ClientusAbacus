
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://ztauiusnkquhifyzkjxh.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp0YXVpdXNua3F1aGlmeXpranhoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MzcyMTQ0NSwiZXhwIjoyMDY5Mjk3NDQ1fQ.4p5T6EhwQx2t0QDLD3S4ZU9TGNSMW7BFPkHmjA6q8dc';

async function testConnection() {
  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Test basic connectivity
    console.log('Testing Supabase connection...');
    
    // Try to list tables
    const { data, error } = await supabase
      .from('pg_tables')
      .select('tablename')
      .eq('schemaname', 'public');
    
    if (error) {
      console.error('Error:', error);
    } else {
      console.log('Success! Connected to Supabase');
      console.log('Tables found:', data?.length || 0);
    }
  } catch (err) {
    console.error('Connection failed:', err);
  }
}

testConnection();
