
import { createClient } from '@supabase/supabase-js'
import dotenv from 'dotenv'

dotenv.config()

const supabaseUrl = process.env.SUPABASE_URL!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

console.log('Testing Supabase connection...')
console.log('URL:', supabaseUrl)
console.log('Service Key (first 20 chars):', supabaseServiceKey?.substring(0, 20) + '...')

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
})

async function testConnection() {
  try {
    // Test basic connection
    const { data, error } = await supabase.from('users').select('count(*)', { count: 'exact' }).limit(1)
    
    if (error) {
      console.error('Supabase connection error:', error)
      
      // Try to get project info instead
      console.log('Trying to get project info...')
      const { data: projectData, error: projectError } = await supabase.rpc('version')
      
      if (projectError) {
        console.error('Project info error:', projectError)
      } else {
        console.log('Project accessible:', projectData)
      }
    } else {
      console.log('Supabase connection successful!')
      console.log('Users table accessible:', data)
    }
  } catch (err) {
    console.error('Connection test failed:', err)
  }
}

testConnection()
